# Group_variable_selection_with_RFGV

Two main objectives:

  1) Fast implementation of CARTGV and RFGV, the extension of CART and Breiman's RF to Grouped inputs (see Arbres de décision et forêts aléatoires pour variables 
     groupées, A. Poterie, 2018).

  2) Development of a group variable selection technique based on RFGV.
